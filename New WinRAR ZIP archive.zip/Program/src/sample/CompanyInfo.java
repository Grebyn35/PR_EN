package sample;

import javafx.beans.property.SimpleStringProperty;

public class CompanyInfo {

    private SimpleStringProperty revenue;
    private SimpleStringProperty cmpName;
    private SimpleStringProperty tel;
    private SimpleStringProperty contactPerson;
    private SimpleStringProperty orgNum;
    private SimpleStringProperty county;
    private SimpleStringProperty branch;

    public CompanyInfo( String tel, String revenue, String cmpName, String contactPerson, String orgNum, String county, String branch){
        this.branch = new SimpleStringProperty(branch);
        this.cmpName = new SimpleStringProperty(cmpName);
        this.contactPerson = new SimpleStringProperty(contactPerson);
        this.tel = new SimpleStringProperty(tel);
        this.branch = new SimpleStringProperty(branch);
        this.county = new SimpleStringProperty(county);
        this.orgNum = new SimpleStringProperty(orgNum);
        this.revenue = new SimpleStringProperty(revenue);
    }
    public String getRevenue() {
        return revenue.get();
    }

    public SimpleStringProperty revenueProperty() {
        return revenue;
    }

    public void setRevenue(String revenue) {
        this.revenue.set(revenue);
    }

    public String getCmpName() {
        return cmpName.get();
    }

    public SimpleStringProperty cmpNameProperty() {
        return cmpName;
    }

    public void setCmpName(String cmpName) {
        this.cmpName.set(cmpName);
    }

    public String getTel() {
        return tel.get();
    }

    public SimpleStringProperty telProperty() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel.set(tel);
    }

    public String getContactPerson() {
        return contactPerson.get();
    }

    public SimpleStringProperty contactPersonProperty() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson.set(contactPerson);
    }

    public String getOrgNum() {
        return orgNum.get();
    }

    public SimpleStringProperty orgNumProperty() {
        return orgNum;
    }

    public void setOrgNum(String orgNum) {
        this.orgNum.set(orgNum);
    }

    public String getCounty() {
        return county.get();
    }

    public SimpleStringProperty countyProperty() {
        return county;
    }

    public void setCounty(String county) {
        this.county.set(county);
    }

    public String getBranch() {
        return branch.get();
    }

    public SimpleStringProperty branchProperty() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch.set(branch);
    }



}
