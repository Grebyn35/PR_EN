package sample;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;
import java.util.*;

public class Main2 extends Application {
	static String searchCounty;
	static String searchBranch;
	static TextField searchWord = new TextField();
	static Text textSearch = new Text("S�kfunktion");
	static CheckBox box1 = new CheckBox("Kontaktperson");
	static CheckBox box2 = new CheckBox("Telefon");
	Stage primaryStage;
	static ComboBox cmbCounties;
	static ComboBox cmbBranches;
	private TableView table = new TableView();
	BorderPane pane = new BorderPane();
	AnchorPane root = new AnchorPane();
	VBox left = new VBox();
//    private ObservableList<CompanyInfo> personData = FXCollections.observableArrayList();
	private ObservableList<CompanyInfo> personData = FXCollections.observableArrayList();
	String counties[] = { "Blekinge", "Dalarna", "Gotland", "Halland", "J�mtland", "J�nk�ping", "Kalmar", "Kronoberg",
			"Norrbotten", "�rebro", "�sterg�tland", "Sk�ne", "Stockholm", "Uppsala", "V�rmland", "V�sterbotten",
			"V�sternorrland", "V�strag�taland" };

	String branches[] = { "Arbetsgivare", "Avlopp & Avfall", "Bank & finnans", "Bemanning", "Bygg", "Data & IT",
			"Detaljhandel", "Fastighetsverksamhet", "F�retagstj�nster", "H�lsa & Sjukv�rd", "H�r & sk�nhetsv�rd" + "",
			"Hotell & Restaurang", "Jordbruk", "Juridik", "Kultur & n�je", "Livsmedelframst�llning", "Media",
			"Motorfordonshandel", "Offentlig f�rvaltning", "�vriga konsumenttj�nster " + "", "Partihandel", "Reklam",
			"Reparationer", "Resebyr�er", "Teknisk konsultverksamhet", "Tillverkning", "Transport",
			"Utbildning & Forskning", "Uthyrning & leasing" };
	private static final String allCompaniesUrl = "https://www.allabolag.se/";

	@Override
	public void start(Stage primaryStage) throws Exception {

		cmbCounties = new ComboBox(FXCollections.observableArrayList(counties));
		
		cmbBranches = new ComboBox(FXCollections.observableArrayList(branches));


		cmbCounties.getSelectionModel().select("L�n");
		cmbBranches.getSelectionModel().select("Bransch");
		cmbCounties.setPrefWidth(130.0);
		cmbBranches.setPrefWidth(130.0);
		box1.setPrefWidth(130);
		box2.setPrefWidth(130);
		left.setMargin(cmbCounties, new Insets(10, 20, 20, 20));
		left.setMargin(cmbBranches, new Insets(-10, 20, 20, 20));
		left.setMargin(box1, new Insets(-300, 20, 20, 20));
		left.setMargin(box2, new Insets(-15, 20, 20, 20));

		Button btnSearch = new Button("Importera");
		Button btnSearch2 = new Button("S�k");
		btnSearch.setPrefWidth(130.0);
		btnSearch2.setPrefWidth(130.0);
		searchWord.setPrefWidth(130.0);
		//textSearch.setX(20.0);
		//textSearch.setY(20.0);
		
		// btnSearch.setOnAction((e) -> {
		// try {
		// fillTable();
		// } catch (IOException ex) {
		// table.setPlaceholder(new Label("No rows to display"));
		// }
		// });

		btnSearch.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				try {
					fillTable();

				} catch (IOException ex) {
					table.setPlaceholder(new Label("No rows to display"));
				}

			}
		});
		btnSearch2.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				try {
					fillTable2();

				} catch (IOException ex) {
					table.setPlaceholder(new Label("No rows to display"));
				}

			}
		});
		left.setMargin(btnSearch, new Insets(70, 20, 20, 20));
		left.setMargin(searchWord, new Insets(125, 20, 20, 20));
		left.setMargin(textSearch, new Insets(100, 20, 20, 20));
		left.setMargin(btnSearch2, new Insets(-10, 20, 20, 20));
		left.getChildren().add(cmbCounties);
		left.getChildren().add(cmbBranches);
		left.getChildren().add(btnSearch);
		left.getChildren().add(searchWord);
		left.getChildren().add(btnSearch2);
		left.getChildren().add(box1);
		left.getChildren().add(box2);
		//left.getChildren().add(textSearch);

		pane.setLeft(left);

		table.setEditable(false);
		createTable();
		pane.setCenter(table);
		Scene scene = new Scene(pane, 988, 400);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	static String cmpName, tel, revenue, contactPerson, orgNum, county, branch;

	private void fillTable() throws IOException {
		ArrayList<String> nameList = new ArrayList<>();
		final String urls�k = allCompaniesUrl + "lista/aktiebolag/24/";
		searchCounty = (String) cmbCounties.getSelectionModel().getSelectedItem();
		searchBranch = (String) cmbBranches.getSelectionModel().getSelectedItem();
		if (searchBranch.contains("Arbetsgivare")) {
			searchBranch = "xv/BRANSCH-,%20ARBETSGIVAR-%20&%20YRKESORG.";
		} else if (searchBranch.contains("Avlopp & Avfall")) {
			searchBranch = "xv/AVLOPP,%20AVFALL,%20EL%20&%20VATTEN";
		} else if (searchBranch.contains("Bank & finnans")) {
			searchBranch = "xv/BANK,%20FINANS%20&%20F�RS�KRING";
		} else if (searchBranch.contains("Bemanning")) {
			searchBranch = "xv/BEMANNING%20&%20ARBETSF�RMEDLING";
		} else if (searchBranch.contains("Bygg")) {
			searchBranch = "xv/BYGG-,%20DESIGN-%20&%20INREDNINGSVERKSAMHET";
		} else if (searchBranch.contains("Data & IT")) {
			searchBranch = "xv/DATA,%20IT%20&%20TELEKOMMUNIKATION";
		} else if (searchBranch.contains("Detaljhandel")) {
			searchBranch = "xv/DETALJHANDEL";
		} else if (searchBranch.contains("Fastighetsversamhet")) {
			searchBranch = "xv/FASTIGHETSVERKSAMHET";
		} else if (searchBranch.contains("F�retagstj�nster")) {
			searchBranch = "xv/F�RETAGSTJ�NSTER";
		} else if (searchBranch.contains("H�lsa & Sjukv�rd")) {
			searchBranch = "xv/H�LSA%20&%20SJUKV�RD";
		} else if (searchBranch.contains("H�lsa & Sjukv�rd")) {
			searchBranch = "xv/H�LSA%20&%20SJUKV�RD";
		} else if (searchBranch.contains("H�r & sk�nhetsv�rd")) {
			searchBranch = "xv/H�R%20&%20SK�NHETSV�RD";
		} else if (searchBranch.contains("Hotell & Restaurang")) {
			searchBranch = "xv/HOTELL%20&%20RESTAURANG";
		} else if (searchBranch.contains("Jordbruk")) {
			searchBranch = "xv/JORDBRUK,%20SKOGSBRUK,%20JAKT%20&%20FISKE";
		} else if (searchBranch.contains("Juridik")) {
			searchBranch = "xv/JURIDIK,%20EKONOMI%20&%20KONSULTTJ�NSTER";
		} else if (searchBranch.contains("Kultur & n�je")) {
			searchBranch = "xv/KULTUR,%20N�JE%20&%20FRITID";
		} else if (searchBranch.contains("Livsmedelframst�llning")) {
			searchBranch = "xv/LIVSMEDELSFRAMST�LLNING";
		} else if (searchBranch.contains("Media")) {
			searchBranch = "xv/MEDIA";
		} else if (searchBranch.contains("Motorfordonshandel")) {
			searchBranch = "xv/MOTORFORDONSHANDEL";
		} else if (searchBranch.contains("Offentlig f�rvaltning")) {
			searchBranch = "xv/OFFENTLIG%20F�RVALTNING%20&%20SAMH�LLE";
		} else if (searchBranch.contains("�vriga konsumenttj�nster")) {
			searchBranch = "xv/�VRIGA%20KONSUMENTTJ�NSTER";
		} else if (searchBranch.contains("Partihandel")) {
			searchBranch = "xv/PARTIHANDEL";
		} else if (searchBranch.contains("Reklam")) {
			searchBranch = "xv/REKLAM,%20PR%20&%20MARKNADSUNDERS�KNING";
		} else if (searchBranch.contains("Reparationer")) {
			searchBranch = "xv/REPARATION%20&%20INSTALLATION";
		} else if (searchBranch.contains("Resebyr�er")) {
			searchBranch = "xv/RESEBYR�%20&%20TURISM";
		} else if (searchBranch.contains("Teknisk konsultverksamhet")) {
			searchBranch = "xv/TEKNISK%20KONSULTVERKSAMHET";
		} else if (searchBranch.contains("Tillverkning")) {
			searchBranch = "xv/TILLVERKNING%20&%20INDUSTRI";
		} else if (searchBranch.contains("Transport")) {
			searchBranch = "xv/TRANSPORT%20&%20MAGASINERING";
		} else if (searchBranch.contains("Utbildning & Forksning")) {
			searchBranch = "xv/UTBILDNING,%20FORSKNING%20&%20UTVECKLING";
		} else if (searchBranch.contains("Uthyrning & leasing")) {
			searchBranch = "xv/UTHYRNING%20&%20LEASING";
		} else {
			System.out.println("");
		}
		if (searchCounty.contains("Blekinge")) {
			searchCounty = "/xl/10";
		} else if (searchCounty.contains("Dalarna")) {
			searchCounty = "/xl/20";
		} else if (searchCounty.contains("Gotland")) {
			searchCounty = "/xl/9";
		} else if (searchCounty.contains("Halland")) {
			searchCounty = "/xl/13";
		} else if (searchCounty.contains("J�mtland")) {
			searchCounty = "/xl/23";
		} else if (searchCounty.contains("J�nk�ping")) {
			searchCounty = "/xl/6";
		} else if (searchCounty.contains("Kalmar")) {
			searchCounty = "/xl/8";
		} else if (searchCounty.contains("Kronoberg")) {
			searchCounty = "/xl/7";
		} else if (searchCounty.contains("Norrbotten")) {
			searchCounty = "/xl/25";
		} else if (searchCounty.contains("�rebro")) {
			searchCounty = "/xl/18";
		} else if (searchCounty.contains("�sterg�tland")) {
			searchCounty = "/xl/5";
		} else if (searchCounty.contains("Sk�ne")) {
			searchCounty = "/xl/12";
		} else if (searchCounty.contains("Stockholm")) {
			searchCounty = "/xl/1";
		} else if (searchCounty.contains("Uppsala")) {
			searchCounty = "/xl/3";
		} else if (searchCounty.contains("V�rmland")) {
			searchCounty = "/xl/17";
		} else if (searchCounty.contains("V�sterbotten")) {
			searchCounty = "/xl/24";
		} else if (searchCounty.contains("V�sternorrland")) {
			searchCounty = "/xl/22";
		} else if (searchCounty.contains("V�strag�taland")) {
			searchCounty = "/xl/14";
		}else {
			searchCounty = "";
		}

		final Document document = Jsoup.connect(urls�k).get();
		for (Element row : document.select("div.search-results.container.page h1")) {
			final String nr = row.select("h1.search-results__header:nth-of-type(1)").text();

			final String urls�kAb = urls�k + searchBranch + searchCounty +"/page/" + parseResultAndReturnPage(nr);

			try {
				final Document document2 = Jsoup.connect(urls�kAb).get();
				for (Element row2 : document2.select("div.box-results article,dl")) {
					final String name = row2.select("article.box").text();
					if (name.contains("AB")) {
						nameList.add(name);
					} else if (name.contains("Aktiebolag")) {
						nameList.add(name);
					} else if (name.contains("Handelsbolag")) {
						nameList.add(name);
					}
				}
				personData = FXCollections.observableArrayList();
				for (int a = 0; a < nameList.size(); a++) {
					String str = nameList.get(a);
					String[] allParts = parseCompanyFindPhoneFindRevenueFindContact(str);
					if (allParts != null) {
						if (!contactPerson.equals("")) {
							if (!tel.equals("")) {
								personData.add(
										new CompanyInfo(tel, revenue, cmpName, contactPerson, orgNum, county, branch));
								System.out.println(personData.size());
							}
						}
					}
				}
				table.setItems(personData);
			} catch (Exception ex) {
				ex.printStackTrace();

			}
		}
		}

	private void fillTable2() throws IOException {
		ArrayList<String> nameList = new ArrayList<>();
		String searchWordInput = searchWord.getText();
		searchWordInput.replaceAll(" ", "%20");
		final String urls�k = allCompaniesUrl + "/what/"+searchWordInput;
		
		final Document document = Jsoup.connect(urls�k).get();
		for (Element row : document.select("div.search-results.container.page h1")) {
			final String nr = row.select("h1.search-results__header:nth-of-type(1)").text();

			final String urls�kAb = urls�k;

			try {
				final Document document2 = Jsoup.connect(urls�kAb).get();
				for (Element row2 : document2.select("div.box-results article,dl")) {
					final String name = row2.select("article.box").text();
					if (name.contains("AB")) {
						nameList.add(name);
					} else if (name.contains("Aktiebolag")) {
						nameList.add(name);
					} else if (name.contains("Handelsbolag")) {
						nameList.add(name);
					}
				}
				personData = FXCollections.observableArrayList();
				for (int a = 0; a < nameList.size(); a++) {
					String str = nameList.get(a);
					String[] allParts = parseCompanyFindPhoneFindRevenueFindContact(str);
					if (allParts != null) {
						//if (!contactPerson.equals("")) {
							//if (!tel.equals("")) {
								personData.add(
										new CompanyInfo(tel, revenue, cmpName, contactPerson, orgNum, county, branch));
								System.out.println(personData.size());
							}
						}
					//}
				//}
				table.setItems(personData);
			} catch (Exception ex) {
				ex.printStackTrace();

			}
		}
		}

	public static String[] parseCompanyFindPhoneFindRevenueFindContact(String allInfo) {

		String[] returnArr = parseCompanyInfo(allInfo);
		String orgNr = returnArr[4];
		String companyName = returnArr[0];
		orgNum = orgNr;
		cmpName = companyName;
		branch = returnArr[3];
		county = returnArr[1];

		searchCounty = (String) cmbCounties.getSelectionModel().getSelectedItem();
		searchBranch = (String) cmbBranches.getSelectionModel().getSelectedItem();
		boolean isSearch = true;
		boolean isBranchSearch = true;

		if ((searchCounty != null && !searchCounty.equals(searchCounty))) {
			if (searchCounty.trim().equals(county.trim())) {
				isBranchSearch = true;
			} else {
				isBranchSearch = false;
			}
		}
		if ((searchBranch != null && !searchBranch.equals(searchBranch))) {
			if (searchBranch.trim().equals(branch.trim())) {
				isSearch = true;
			} else {
				isSearch = false;
			}
		}
		if (isBranchSearch && isSearch) {
			final String url1 = allCompaniesUrl + orgNr + "/" + formatName(companyName);
			try {
				final Document document = Jsoup.connect(url1).get();
				for (Element row : document.select("div.page.company.container.hidden div")) {
					final String telNr = row.select("div:nth-of-type(2)").text();
//                System.out.println(url1);

					if (telNr.contains("Telefon")) {
						tel = containsTelephone(telNr);
					} else {
						tel = "";
					}

					if (telNr.contains("Oms�ttning")) {
						revenue = containsRevenue(telNr);
					} else {
						revenue = "";
//                    System.out.println("oms�ttning ej tillg�nglig");
					}

					final String url = allCompaniesUrl + orgNr + "/" + formatName(companyName);
					try {

						contactPerson = findContactPerson(url);
					} catch (ArrayIndexOutOfBoundsException ex) {
						contactPerson = "";
					}
					return returnArr;
				}
			} catch (Exception ex) {
				ex.printStackTrace();

			}
		}

		return null;
	}

	public static String[] parseCompanyInfo(String allInfo) {
		List<String> splitted = Arrays.asList(allInfo.split(" "));
		int orgNrIndex = splitted.indexOf("Org.nummer");
		String companyName = "";
		for (int i = 0; i < orgNrIndex - 1; i++) {
			String ending = i == orgNrIndex - 2 ? "" : "-";
			companyName += splitted.get(i) + ending;
		}
		String location = splitted.get(orgNrIndex - 1);
		String orgNrOriginal = splitted.get(orgNrIndex + 1);
		String[] orgNrParts = splitted.get(orgNrIndex + 1).split("-");
		String orgNr = orgNrParts[0] + orgNrParts[1];

		String companyDescription = "";
		for (int i = orgNrIndex + 3; i < splitted.size(); i++) {
			companyDescription += splitted.get(i);
		}
		String urlName = companyName;
		return new String[] { companyName, location, orgNrOriginal, companyDescription, orgNr, urlName };
	}

	public static String containsTelephone(String input) throws IOException {
		String telefon[] = input.split("Telefon ");
		String telefonNr = telefon[1];
		String telTel[] = telefonNr.split(" ");
//        System.out.println("tel nr: " + telTel[0]);
		return telTel[0];
	}

	public static String containsRevenue(String input) throws IOException {
		String oms�ttning[] = input.split("Oms�ttning ");
		String oms�ttningsNr = oms�ttning[1];
		String Oms�ttning[] = oms�ttningsNr.split("Res");
//        System.out.println("oms�ttning: " + Oms�ttning[0] + "tkr");
		return Oms�ttning[0];
	}

	public static String findContactPerson(String inputUrl) throws IOException {
		final Document document1 = Jsoup.connect(inputUrl).get();
		for (Element row1 : document1.select("div.cc-flex-grid a")) {
			final String name = row1.select("a.btn-link").text();
			String kontaktPerson[] = name.split("L�s mer");
			String Person = kontaktPerson[0];
			return Person;
		}

		return "";
	}

	public static String formatName(String oldName) {
		return oldName.replaceAll("�", "a").replaceAll("�", "a").replaceAll("�", "o").replaceAll("&", "")
				.replaceAll("--", "-");
	}

	public static int parseResultAndReturnPage(String nr) {
		int sida;
		String s�kresultat[] = nr.split("S�kresultat: ");
		String s�kResultatNr = s�kresultat[1];
		String resultatNr[] = s�kResultatNr.split("tr�ffar");
		String sidor = resultatNr[0].replace(" ", "");
		int pageNr = Integer.parseInt(sidor);
		int sidNr = pageNr / 20;
		Random rand = new Random();
		sida = rand.nextInt(sidNr);
		if (sida > 400) {
			sida = rand.nextInt(400);
		}
		return sida;
	}

	private void createTable() {
		TableColumn<CompanyInfo, String> colTelephone = new TableColumn<>("telephone");
		TableColumn<CompanyInfo, String> colRevenue = new TableColumn<>("Revenue");
		TableColumn<CompanyInfo, String> colCompanyName = new TableColumn<>("Company Name");
		TableColumn<CompanyInfo, String> colContactPerson = new TableColumn<>("Contact Person");
		TableColumn<CompanyInfo, String> colOrganisationNumber = new TableColumn<>("Organisation Number");
		TableColumn<CompanyInfo, String> colCounty = new TableColumn<>("County");
		TableColumn<CompanyInfo, String> colBranch = new TableColumn<>("Branch");
		colTelephone.setCellValueFactory(new PropertyValueFactory<>("tel"));
		colRevenue.setCellValueFactory(new PropertyValueFactory<>("revenue"));
		colCompanyName.setCellValueFactory(new PropertyValueFactory<>("cmpName"));
		colContactPerson.setCellValueFactory(new PropertyValueFactory<>("contactPerson"));
		colOrganisationNumber.setCellValueFactory(new PropertyValueFactory<>("orgNum"));
		colCounty.setCellValueFactory(new PropertyValueFactory<>("county"));
		colBranch.setCellValueFactory(new PropertyValueFactory<>("branch"));

		colRevenue.setPrefWidth(70.0);
		colCompanyName.setPrefWidth(150);
		colContactPerson.setPrefWidth(150.0);
		colOrganisationNumber.setPrefWidth(130.0);
		colCounty.setPrefWidth(110.0);
		colBranch.setPrefWidth(160.0);
		System.out.println(colRevenue.getWidth());
		table.getColumns().addAll(colTelephone, colRevenue, colCompanyName, colContactPerson, colOrganisationNumber,
				colCounty, colBranch);
	}

	public static void main(String[] args) {
		launch(args);
	}
}
